$(document).ready(function() {

	var app_url = 'http://localhost:1818';
	var socket = io.connect(app_url);

	$('.round').hide();

    if($(window).width() < 600) {
        $('.my_button').on('click', function() {
            var color = $(this).attr('data-color');
            socket.emit('buttonColor', {color: color});
        });
    } else {
        $('.my_button').hide();
        socket.on('showColor', function(color) {
            $('.'+color.color+'_round').show();
            setTimeout(function() {
                $('.'+color.color+'_round').hide();
            }, 200);
        });
    }

    

    

});